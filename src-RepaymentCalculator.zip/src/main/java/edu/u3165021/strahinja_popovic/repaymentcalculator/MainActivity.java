package edu.u3165021.strahinja_popovic.repaymentcalculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import java.text.DecimalFormat;

import edu.u3165021.strahinja_popovic.assignmentpart3_repaymentcalculator.R;

/**
 * Author name: Strahinja Popovic
 * Developer name: Codex Developer
 * Application: Repayment Calculator
 * Date: 1/17/2017
 */

public class MainActivity extends ActionBarActivity
{
    private int years = 0;
    private int numberTotalPaymentsN;
    private int numberYearPaymentsM;
    private double amount = 0.00;
    private double rate = 0.00;
    private double module = 0.00;
    private double mPower = 0.00;
    private double result = 0.00;
    private int dataResult = 0;
    private double floorResult = 0;
    private String fResult = "";
    private String strAmount = "";
    private String strYears = "";
    private String strRate = "";
    private String strResult = "";
    private DecimalFormat df = new DecimalFormat("#,###,##0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Spinner spinner = (Spinner) findViewById(R.id.spinnerRepaymentPeriod);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.repaymentType, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        final EditText txtAmount = (EditText) findViewById(R.id.txtAmount);
        final EditText txtYears = (EditText) findViewById(R.id.txtYears);
        final EditText txtRate = (EditText) findViewById(R.id.txtRate);

        final TextView txtResult = (TextView) findViewById(R.id.txtLabelResult);

        final Button btnCalculate = (Button) findViewById(R.id.btnCalculate);
        final Button btnReset = (Button) findViewById(R.id.btnReset);

        final RelativeLayout layoutMain = (RelativeLayout) findViewById(R.id.layoutMain);

        layoutMain.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
            }
        });
        btnCalculate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                strAmount = txtAmount.getText().toString();
                strRate = txtRate.getText().toString();
                strYears = txtYears.getText().toString();

                if(strAmount.equals("") || strYears.equals("") || strRate.equals(""))
                {
                    txtResult.setText("Insert all fields.");
                }
                else
                {
                    try
                    {
                        years = Integer.parseInt(strYears);
                        amount = Double.parseDouble(strAmount);
                        rate = Double.parseDouble(strRate);

                        if((amount > 0) && (rate > 0) && (years > 0))
                        {
                            if(spinner.getSelectedItem().toString().equalsIgnoreCase("Select option"))
                            {
                                numberTotalPaymentsN = 0;
                                numberYearPaymentsM = 0;
                                txtResult.setText("Make selection.");
                            }
                            else if(spinner.getSelectedItem().toString().equalsIgnoreCase("Monthly"))
                            {
                                numberTotalPaymentsN = (12 * Integer.parseInt(txtYears.getText().toString()));
                                numberYearPaymentsM = 12;
                                strResult = "Monthly payment.";
                            }
                            else if(spinner.getSelectedItem().toString().equalsIgnoreCase("Fortnight"))
                            {
                                numberTotalPaymentsN = (26 * Integer.parseInt(txtYears.getText().toString()));
                                numberYearPaymentsM = 26;
                                strResult = "Fortnight payment.";
                            }
                            else if(spinner.getSelectedItem().toString().equalsIgnoreCase("Weekly"))
                            {
                                numberTotalPaymentsN = (52 * Integer.parseInt(txtYears.getText().toString()));
                                numberYearPaymentsM = 52;
                                strResult = "Weekly payment.";
                            }

                            if(numberTotalPaymentsN > 0 && numberYearPaymentsM > 0)
                            {
                                module = (rate / (100 * numberYearPaymentsM));
                                mPower = Math.pow((module + 1), numberTotalPaymentsN);
                                result = (amount * (module + (module / (mPower - 1))));
                                floorResult = (int) result + 0.5;

                                if(result > floorResult)
                                {
                                    dataResult = (int) Math.ceil(result);
                                }
                                else if(result < floorResult && result > (int) result)
                                {
                                    dataResult = (int) Math.floor(result);
                                }
                                else if(result == (int) result)
                                {
                                    dataResult = (int) result;
                                }

                                fResult = df.format(dataResult);
                                txtResult.setText("DataResult = " + dataResult);
                                txtResult.setText("Result: $" + fResult + " " + strResult
                                        + "\n----------------"
                                        + "\nTotal repayment: $" + df.format(dataResult * numberTotalPaymentsN)
                                        + "\n---------------- ");
                            }
                            else
                            {
                                txtResult.setText("Select an option.");
                            }
                        }
                        else
                        {
                            txtResult.setText("Only positive numbers.");
                        }
                    }
                    catch(NumberFormatException ex)
                    {
                        txtResult.setText("Only numbers for inputs.");
                    }
                }
            }
        });
        btnReset.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                /*
                txtAmount.setText("");
                txtYears.setText("");
                txtRate.setText("");
                txtResult.setText("Message...\nIf you have lodge a deposit\njust deduct that amount from\nAmount borrowed.");
                spinner.setSelection(0);
                */
                Intent i = getBaseContext().getPackageManager().getLaunchIntentForPackage(getBaseContext().getPackageName());
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);


            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        Intent i;
        switch(item.getItemId())
        {
            case R.id.menuDescription:
                i = new Intent(this, DescriptionActivity.class);
                startActivity(i);
                return true;
            case R.id.menuDescriptionPlusOne:
                i = new Intent(this, DescriptionPlus1Activity.class);
                startActivity(i);
                return true;
            case R.id.menuDescriptionPlusTwo:
                i = new Intent(this, SpecificationActivity.class);
                startActivity(i);
                return true;
        }
        return false;
    }
}
