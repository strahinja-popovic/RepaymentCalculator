package edu.u3165021.strahinja_popovic.repaymentcalculator;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import edu.u3165021.strahinja_popovic.assignmentpart3_repaymentcalculator.R;

/**
 * Author name: Strahinja Popovic
 * Developer name: Codex Developer
 * Application: Repayment Calculator
 * Date: 1/17/2017
 */

public class SpecificationActivity extends ActionBarActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.description_spec);

        final Button btnPrev = (Button) findViewById(R.id.btnPrevious);
        final Button btnHome = (Button) findViewById(R.id.btnHome);

        btnPrev.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                try
                {
                    onBackPressed();
                }
                catch (Exception ex)
                {
                    Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

        btnHome.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent();
                i = new Intent(SpecificationActivity.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_description_plus_two, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        Intent i;
        switch(item.getItemId())
        {
            case R.id.menuMainApp:
                i = new Intent(this, MainActivity.class);
                startActivity(i);
                return true;
            case R.id.menuDescription:
                i = new Intent(this, DescriptionActivity.class);
                startActivity(i);
                return true;
            case R.id.menuDescriptionPlusOne:
                i = new Intent(this, DescriptionPlus1Activity.class);
                startActivity(i);
                return true;
        }
        return false;
    }
}
